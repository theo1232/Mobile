﻿using System.ComponentModel.DataAnnotations;

namespace BarraByTechAPI.Models
{
    public class ValorProduto
    {
        [Key]
        public Guid ValorProdutoId { get; set; } = Guid.NewGuid();

        [Required(ErrorMessage = "O ProdutoId é obrigatório.")]
        public Guid ProdutoId { get; set; }

        public Produto? Produto { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "O valor do boleto deve ser maior ou igual a zero.")]
        public decimal Boleto { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "O valor do cartão deve ser maior ou igual a zero.")]
        public decimal Cartao { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "O valor à vista deve ser maior ou igual a zero.")]
        public decimal Vista { get; set; }

        [Range(0, double.MaxValue, ErrorMessage = "O valor promocional deve ser maior ou igual a zero.")]
        public decimal Promocao { get; set; }
    }
}