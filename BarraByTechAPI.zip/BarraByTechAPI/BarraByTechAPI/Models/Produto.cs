﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BarraByTechAPI.Models
{
    public class Produto
    {
        [Key]
        public Guid ProdutoId { get; set; } = Guid.NewGuid();

        [Required(ErrorMessage = "O nome do produto é obrigatório.")]
        [StringLength(100, ErrorMessage = "O nome pode ter no máximo 100 caracteres.")]
        public string Nome { get; set; } = string.Empty;

        [StringLength(500, ErrorMessage = "A descrição pode ter no máximo 500 caracteres.")]
        public string Descricao { get; set; } = string.Empty;

        [Url(ErrorMessage = "A imagem deve ser uma URL válida.")]
        public string Imagem { get; set; } = string.Empty;

        [Required(ErrorMessage = "A categoria é obrigatória.")]
        public Guid CategoriaId { get; set; }

        [ForeignKey("CategoriaId")]
        public Categoria? Categoria { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "O estoque mínimo não pode ser negativo.")]
        public int EstoqueMin { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "O estoque atual não pode ser negativo.")]
        public int EstoqueAtual { get; set; }

        public DateTime DataCriacao { get; set; } = DateTime.UtcNow;
        public DateTime? DataAlteracao { get; set; }

        public void AtualizarDataAlteracao() => DataAlteracao = DateTime.UtcNow;
    }
}
