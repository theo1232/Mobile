﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BarraByTechAPI.Data;
using BarraByTechAPI.Models;

namespace BarraByTechAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EnderecosClienteController : ControllerBase
    {
        private readonly AppDbContext _context;

        public EnderecosClienteController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/EnderecosCliente
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EnderecoCliente>>> GetEnderecosCliente()
        {
            return await _context.EnderecosCliente
                .Include(e => e.Cliente) // <-- carrega cliente junto
                .ToListAsync();
        }

        // GET: api/EnderecosCliente/5
        [HttpGet("{id}")]
        public async Task<ActionResult<EnderecoCliente>> GetEnderecoCliente(Guid id)
        {
            var enderecoCliente = await _context.EnderecosCliente
                .Include(e => e.Cliente)
                .FirstOrDefaultAsync(e => e.EnderecoId == id);

            if (enderecoCliente == null)
            {
                return NotFound();
            }

            return enderecoCliente;
        }

        // PUT: api/EnderecosCliente/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutEnderecoCliente(Guid id, EnderecoCliente enderecoCliente)
        {
            if (id != enderecoCliente.EnderecoId)
            {
                return BadRequest("IDs não coincidem.");
            }

            _context.Entry(enderecoCliente).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EnderecoClienteExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/EnderecosCliente
        [HttpPost]
        public async Task<ActionResult<EnderecoCliente>> PostEnderecoCliente(EnderecoCliente enderecoCliente)
        {
            // não precisa enviar Cliente no JSON, só o UserId!
            enderecoCliente.EnderecoId = Guid.NewGuid();

            _context.EnderecosCliente.Add(enderecoCliente);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetEnderecoCliente),
                new { id = enderecoCliente.EnderecoId },
                enderecoCliente
            );
        }

        // DELETE: api/EnderecosCliente/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEnderecoCliente(Guid id)
        {
            var enderecoCliente = await _context.EnderecosCliente.FindAsync(id);
            if (enderecoCliente == null)
            {
                return NotFound();
            }

            _context.EnderecosCliente.Remove(enderecoCliente);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool EnderecoClienteExists(Guid id)
        {
            return _context.EnderecosCliente.Any(e => e.EnderecoId == id);
        }
    }
}