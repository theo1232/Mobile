﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BarraByTechAPI.Data;
using BarraByTechAPI.Models;

namespace BarraByTechAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValorProdutosController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ValorProdutosController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/ValorProdutoes
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ValorProduto>>> GetValorProdutos()
        {
            return await _context.ValorProdutos
                .Include(v => v.Produto)
                    .ThenInclude(p => p.Categoria)
                .ToListAsync();
        }

        // GET: api/ValorProdutoes/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ValorProduto>> GetValorProduto(Guid id)
        {
            var valorProduto = await _context.ValorProdutos
                .Include(v => v.Produto)
                    .ThenInclude(p => p.Categoria)
                .FirstOrDefaultAsync(e => e.ValorProdutoId == id);

            if (valorProduto == null)
            {
                return NotFound();
            }

            return valorProduto;
        }

        // PUT: api/ValorProdutoes/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutValorProduto(Guid id, ValorProduto valorProduto)
        {
            if (id != valorProduto.ValorProdutoId)
            {
                return BadRequest();
            }

            _context.Entry(valorProduto).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ValorProdutoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/ValorProdutoes
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<ValorProduto>> PostValorProduto(ValorProduto valorProduto)
        {
            _context.ValorProdutos.Add(valorProduto);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetValorProduto", new { id = valorProduto.ValorProdutoId }, valorProduto);
        }

        // DELETE: api/ValorProdutoes/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteValorProduto(Guid id)
        {
            var valorProduto = await _context.ValorProdutos.FindAsync(id);
            if (valorProduto == null)
            {
                return NotFound();
            }

            _context.ValorProdutos.Remove(valorProduto);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ValorProdutoExists(Guid id)
        {
            return _context.ValorProdutos.Any(e => e.ValorProdutoId == id);
        }
    }
}
